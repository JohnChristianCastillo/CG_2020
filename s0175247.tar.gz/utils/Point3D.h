//
// Created by reed on 15.05.19.
//

#ifndef UTILS_POINT3D_H
#define UTILS_POINT3D_H


class Point3D {
public:
    double x;
    double y;
    double z;
    Point3D(double ix, double iy, double iz):x(ix), y(iy), z(iz){}

};


#endif //UTILS_POINT3D_H
